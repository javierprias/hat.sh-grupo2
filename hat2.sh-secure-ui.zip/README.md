# 🧩 Proyecto: Hat.sh Reforged  
### 👥 Grupo 2  

## 💡 Presentación del Proyecto  
**Hat.sh Reforged** es una versión reforzada y personalizada de la aplicación web de código abierto Hat.sh, centrada en la implementación de prácticas **DevSecOps** y en la mejora de la **seguridad** y la **interfaz gráfica**.

El objetivo del proyecto es crear una versión más segura y optimizada, lista para su despliegue en entornos de producción mediante Docker.

## ⚙️ Objetivo General  
Fortalecer la aplicación original Hat.sh mediante:  
- Análisis de vulnerabilidades (**SAST**, **SCA**).  
- Mitigación de riesgos detectados.  
- Rediseño visual moderno.  
- Imagen Docker reforzada y pública.  

## 🧱 Tecnologías Utilizadas  
- HTML5 / CSS3  
- Node.js  
- Docker  
- GitHub Actions  
- Docker Hub  

## 🧰 Refuerzo de Seguridad  
| Vulnerabilidad | Riesgo | Acción Correctiva |
|----------------|--------|------------------|
| Dependencias desactualizadas | Medio | Actualización con `npm ci` |
| Ejecución como root | Alto | Usuario no root (`hat`) |
| Contexto de build amplio | Bajo | Implementación de `.dockerignore` |
| Falta de healthcheck | Medio | Añadido `HEALTHCHECK` |
| Limpieza post-build | Bajo | Eliminación de archivos temporales |
| Falta de pipeline CI | Medio | Configuración de GitHub Actions |

## 🎨 Interfaz Gráfica  
- Tema oscuro tipo terminal con acentos verde-azulados.  
- Tipografía **Roboto Mono**.  
- Botones con brillo y transiciones suaves.  
- Diseño responsive.  
- Logo textual: *“Hat.sh Reforged – Grupo 2”*.  
- Footer: `© 2025 Grupo 2 – Hat.sh Reforged | DevSecOps Project`.  

## 🔗 Repositorios del Proyecto  
🐳 Docker Hub: https://hub.docker.com/r/jonateven12/hat2.sh  
💻 GitHub: https://github.com/jonateven/hat2.sh  

## 📜 Licencia  
Licencia MIT, respetando los derechos del repositorio original Hat.sh.
